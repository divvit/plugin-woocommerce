#Divvit Tracking Woocommerce Plugin

Author: Johannes Bugiel
http://www.outofscope.io

Version history:

* 1.0.0: Initial version
* 1.0.1: Fixed problem with cart updates
* 1.0.2: Trigger cart updates via PHP upon AJAX requests

To build:

  cd src
  zip -r ../dist/divvit-woocommerce-plugin-1.0.2.zip . -x "*.DS_Store"