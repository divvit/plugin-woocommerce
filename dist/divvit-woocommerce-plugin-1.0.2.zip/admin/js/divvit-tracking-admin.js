(function( $ ) {
	'use strict';
})( jQuery );
